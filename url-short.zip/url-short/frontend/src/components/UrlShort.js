import React, { useState } from "react";
import axios from "axios";

const UrlShortener = () => {
  const [longUrl, setLongUrl] = useState("");
  const [shortUrl, setShortUrl] = useState("");
  const [ipAddress, setIpAddress] = useState("");
  const [location, setLocation] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await axios.post("http://localhost:5000/shorten", {
        longUrl,
      });
      const { shortUrl, ipAddress, location } = response.data;
      setShortUrl(shortUrl);
      setIpAddress(ipAddress);
      setLocation(location);

      // TagManager.dataLayer({
      //   dataLayer: {
      //     event: "URL Shortened",
      //     event_category: "Engagement",
      //     event_label: shortUrl,
      //   },
      // });
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">URL Shortener</h1>
      <div className="w-full max-w-md">
        <input
          type="text"
          className="w-full px-4 py-2 border border-gray-300 rounded-md mb-4 focus:outline-none focus:border-blue-500"
          placeholder="Enter URL"
          value={longUrl}
          onChange={(e) => setLongUrl(e.target.value)}
        />
        <button
          className="w-full bg-blue-500 text-white px-4 py-2 rounded-md transition duration-300 hover:bg-blue-600 focus:outline-none"
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? "Loading..." : "Shorten URL"}
        </button>
        {error && <p className="text-red-500 mt-2">{error}</p>}
        {shortUrl && (
          <div className="mt-4 border border-gray-300 rounded-md p-4 bg-white">
            <p>
              <strong>Short URL:</strong>{" "}
              <a href={shortUrl} target="_blank" rel="noopener noreferrer">
                {shortUrl}
              </a>
            </p>
            <p>
              <strong>IP Address:</strong> {ipAddress}
            </p>
            <p>
              <strong>Location:</strong> {location}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default UrlShortener;
