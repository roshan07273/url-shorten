import "./App.css";
import UrlShort from "./components/UrlShort";

function App() {
  return (
    <div className="App">
      <UrlShort />
    </div>
  );
}

export default App;
