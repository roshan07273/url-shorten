const express = require("express");
const router = express.Router();
const validUrl = require("valid-url");
const shortid = require("shortid");
const Url = require("../models/Url");
const axios = require("axios");

router.post("/", async (req, res) => {
  const { longUrl } = req.body;
  const baseUrl = "http://localhost:5000";

  // Fetch IP address
  let ipAddress = req.ip;

  try {
    const ipifyResponse = await axios.get("https://api.ipify.org?format=json");
    ipAddress = ipifyResponse.data.ip;

    // Fetch location based on IP address
    const ipApiUrl = `http://ip-api.com/json/${ipAddress}`;
    const ipLocationResponse = await axios.get(ipApiUrl);

    const locationData = ipLocationResponse.data;
    const location = `${locationData.country}, ${locationData.regionName} , ${locationData.city}`;

    // Generate short URL code
    const urlCode = shortid.generate();

    // Check if long URL is valid
    if (validUrl.isUri(longUrl)) {
      try {
        let url = await Url.findOne({ longUrl });

        if (url) {
          res.json(url);
        } else {
          const shortUrl = `${baseUrl}/${urlCode}`;

          url = new Url({
            longUrl,
            shortUrl,
            urlCode,
            ipAddress,
            location,
            date: new Date(),
          });

          await url.save();
          res.json(url);
        }
      } catch (err) {
        console.error(err);
        res.status(500).json("Server error");
      }
    } else {
      res.status(401).json("Invalid long URL");
    }
  } catch (error) {
    console.error("Error fetching IP address and location:", error);
    res.status(500).json("Server error");
  }
});

module.exports = router;
